# Expression measurements: 2026-09-14

Use this archive to inspect and reproduce the GitHub Actions expression measurements after hosted logs expire. Start with summary.md for expressions and results, or results.json for structured observations and run identities.

68 runs completed successfully; 2 runs failed during expression evaluation; 15 dispatches were rejected. All 85 temporary refs were removed. Runner: 2.337.0. Node: v22.23.2. Image: ubuntu24 20260907.300.1.

Each case directory contains its exact workflow.yml, dispatch-request.json and dispatch-response.json. Accepted runs also contain logs.txt, logs.stderr.txt and run.json. Response files retain HTTP status, response body and diagnostic headers; run.json contains the recorded run identity and timestamps.

source/ contains the driver and corpus used for this capture, with their original SHA-256 values recorded in results.json. corpus.json records the selected cases; refs.json records their cleanup. SHA256SUMS lists the hash of every other file in the archive.
