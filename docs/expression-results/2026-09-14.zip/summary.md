# GitHub Actions expression measurements

These measurements show how GitHub interprets expressions and supplied inputs. Each case records the expressions and their observed results together, so you can reproduce them or compare another evaluator.

Supplied inputs show the declared workflow input type and the JSON value sent to the dispatch API. Service values come from the workflow run name; runner values come from a step on the hosted runner. Both preserve the text returned by `toJSON()`. Strict JSON input parsing records JavaScript's `JSON.parse()` result. A dash marks a result that was not produced; any associated error appears above its table.

Started: 2026-09-14T19:18:30.838Z. Finished: 2026-09-14T19:31:39.805Z.

API version: <code>2026-03-10</code>. Repository: <code>kjanat/actionlint</code>; source: <code>646c0010878ae28d76288e5f7184962c262bbdc6</code>.

85/85 cases recorded; 708 checks listed.

## literal-01

Run: 34886102378, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>+1</code> | <code>1</code> | <code>1</code> |

## literal-02

Run: 34886110940, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>-0</code> | <code>0</code> | <code>-0</code> |

## literal-03

Run: 34886120037, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>-1</code> | <code>-1</code> | <code>-1</code> |

## literal-04

Run: 34886129730, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>-Infinity</code> | <code>-Infinity</code> | <code>-Infinity</code> |

## literal-05

Run: 34886137174, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>.5</code> | <code>0.5</code> | <code>0.5</code> |

## literal-06

Run: 34886145772, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>.5e1</code> | <code>5</code> | <code>5</code> |

## literal-07

Run: 34886153638, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0</code> | <code>0</code> | <code>0</code> |

## literal-08

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '+'. Located at position 12 within expression: toJSON(0.1 + 0.2), (Line: 30, Col: 20): Unexpected symbol: '+'. Located at position 12 within expression: toJSON(0.1 + 0.2)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0.1 + 0.2</code> | — | — |

## literal-09

Run: 34886171678, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>00</code> | <code>0</code> | <code>0</code> |

## literal-10

Run: 34886180783, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0123</code> | <code>123</code> | <code>123</code> |

## literal-11

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '0B101'. Located at position 8 within expression: toJSON(0B101), (Line: 30, Col: 20): Unexpected symbol: '0B101'. Located at position 8 within expression: toJSON(0B101)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0B101</code> | — | — |

## literal-12

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '0O17'. Located at position 8 within expression: toJSON(0O17), (Line: 30, Col: 20): Unexpected symbol: '0O17'. Located at position 8 within expression: toJSON(0O17)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0O17</code> | — | — |

## literal-13

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '0X1F'. Located at position 8 within expression: toJSON(0X1F), (Line: 30, Col: 20): Unexpected symbol: '0X1F'. Located at position 8 within expression: toJSON(0X1F)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0X1F</code> | — | — |

## literal-14

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '0b101'. Located at position 8 within expression: toJSON(0b101), (Line: 30, Col: 20): Unexpected symbol: '0b101'. Located at position 8 within expression: toJSON(0b101)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0b101</code> | — | — |

## literal-15

Run: 34886220182, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0o17</code> | <code>15</code> | <code>15</code> |

## literal-16

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '0o8'. Located at position 8 within expression: toJSON(0o8), (Line: 30, Col: 20): Unexpected symbol: '0o8'. Located at position 8 within expression: toJSON(0o8)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0o8</code> | — | — |

## literal-17

Run: 34886236642, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0x01</code> | <code>1</code> | <code>1</code> |

## literal-18

Run: 34886246264, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0x0123</code> | <code>291</code> | <code>291</code> |

## literal-19

Run: 34886255384, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0x0e1</code> | <code>225</code> | <code>225</code> |

## literal-20

Run: 34886265427, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0x1F</code> | <code>31</code> | <code>31</code> |

## literal-21

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '0xG'. Located at position 8 within expression: toJSON(0xG), (Line: 30, Col: 20): Unexpected symbol: '0xG'. Located at position 8 within expression: toJSON(0xG)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>0xG</code> | — | — |

## literal-22

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '+'. Located at position 10 within expression: toJSON(1 + 1), (Line: 30, Col: 20): Unexpected symbol: '+'. Located at position 10 within expression: toJSON(1 + 1)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1 + 1</code> | — | — |

## literal-23

Run: 34886291235, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1.</code> | <code>1</code> | <code>1</code> |

## literal-24

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '1.0e+'. Located at position 8 within expression: toJSON(1.0e+), (Line: 30, Col: 20): Unexpected symbol: '1.0e+'. Located at position 8 within expression: toJSON(1.0e+)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1.0e+</code> | — | — |

## literal-25

Run: 34886307367, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1.0e+99</code> | <code>1E+99</code> | <code>1E+99</code> |

## literal-26

Run: 34886316569, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1.5</code> | <code>1.5</code> | <code>1.5</code> |

## literal-27

Run: 34886325414, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1E+5</code> | <code>100000</code> | <code>100000</code> |

## literal-28

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '1&#95;000'. Located at position 8 within expression: toJSON(1&#95;000), (Line: 30, Col: 20): Unexpected symbol: '1&#95;000'. Located at position 8 within expression: toJSON(1&#95;000)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1&#95;000</code> | — | — |

## literal-29

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '1e'. Located at position 8 within expression: toJSON(1e), (Line: 30, Col: 20): Unexpected symbol: '1e'. Located at position 8 within expression: toJSON(1e)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e</code> | — | — |

## literal-30

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '1e+'. Located at position 8 within expression: toJSON(1e+), (Line: 30, Col: 20): Unexpected symbol: '1e+'. Located at position 8 within expression: toJSON(1e+)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e+</code> | — | — |

## literal-31

Run: 34886356628, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e+01</code> | <code>10</code> | <code>10</code> |

## literal-32

Run: 34886365254, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e+5 == 100000</code> | <code>true</code> | <code>true</code> |

## literal-33

Run: 34886374454, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e+5</code> | <code>100000</code> | <code>100000</code> |

## literal-34

Run: 34886382624, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e-0</code> | <code>1</code> | <code>1</code> |

## literal-35

Run: 34886390920, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e-5</code> | <code>1E-05</code> | <code>1E-05</code> |

## literal-36

Run: 34886399564, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e01</code> | <code>10</code> | <code>10</code> |

## literal-37

Run: 34886408294, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e0123</code> | <code>1E+123</code> | <code>1E+123</code> |

## literal-38

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '1e309'. Located at position 8 within expression: toJSON(1e309), (Line: 30, Col: 20): Unexpected symbol: '1e309'. Located at position 8 within expression: toJSON(1e309)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e309</code> | — | — |

## literal-39

Run: 34886423551, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e5</code> | <code>100000</code> | <code>100000</code> |

## literal-40

Dispatch error (expression-parser): <code>Invalid Argument - failed to parse workflow: (Line: 2, Col: 11): Unexpected symbol: '1e5e5'. Located at position 8 within expression: toJSON(1e5e5), (Line: 30, Col: 20): Unexpected symbol: '1e5e5'. Located at position 8 within expression: toJSON(1e5e5)</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>1e5e5</code> | — | — |

## literal-41

Run: 34886437720, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>2147483648</code> | <code>2147483648</code> | <code>2147483648</code> |

## literal-42

Run: 34886446478, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>9007199254740993</code> | <code>9.00719925474099E+15</code> | <code>9.00719925474099E+15</code> |

## literal-43

Run: 34886455784, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>Infinity</code> | <code>Infinity</code> | <code>Infinity</code> |

## literal-44

Run: 34886464547, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>NaN</code> | <code>NaN</code> | <code>NaN</code> |

## json-block-comment

Supplied input: string: <code>"/&#42; comment &#42;/31"</code>.

Run: 34886473914, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token '/', "/&#42; comment &#42;/31" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>" comment "</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-comment-after-value

Supplied input: string: <code>"{&#92;"approved&#92;":true/&#42;x&#42;/,&#92;"n&#92;":1}"</code>.

Run: 34886482953, attempt 1.

Strict JSON input parsing: Rejected: <code>Expected ',' or '}' after property value in JSON at position 16 (line 1 column 17)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>1</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "approved": true,<br>  "n": 1<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-comment-before-denial

Supplied input: string: <code>"/&#42; attacker comment &#42;/{&#92;"approved&#92;":false,&#92;"role&#92;":&#92;"user&#92;",&#92;"n&#92;":1}"</code>.

Run: 34886491504, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token '/', "/&#42; attacke"... is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>" attacker comment "</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-comment-before-value

Supplied input: string: <code>"{&#92;"approved&#92;":/&#42;x&#42;/true,&#92;"n&#92;":1}"</code>.

Run: 34886499651, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token '/', ..."approved":/&#42;x&#42;/true,"... is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>1</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "approved": true,<br>  "n": 1<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-decimal

Supplied input: string: <code>"31"</code>.

Run: 34886507974, attempt 1.

Strict JSON input parsing: Parsed: <code>31</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>31</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-decision-baseline

Supplied input: string: <code>"{&#92;"approved&#92;":true,&#92;"role&#92;":&#92;"admin&#92;",&#92;"n&#92;":1}"</code>.

Run: 34886515224, attempt 1.

Strict JSON input parsing: Parsed: <code>{ approved: true, role: 'admin', n: 1 }</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>1</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "approved": true,<br>  "role": "admin",<br>  "n": 1<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>false</code> |

## json-duplicate-number

Supplied input: string: <code>"{&#92;"n&#92;":1,&#92;"n&#92;":2}"</code>.

Run: 34886522619, attempt 1.

Strict JSON input parsing: Parsed: <code>{ n: 2 }</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>2</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": 2<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-duplicate-role

Supplied input: string: <code>"{&#92;"role&#92;":&#92;"user&#92;",&#92;"role&#92;":&#92;"admin&#92;"}"</code>.

Run: 34886530328, attempt 1.

Strict JSON input parsing: Parsed: <code>{ role: 'admin' }</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "role": "admin"<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>false</code> |

## json-hex

Supplied input: string: <code>"0x1F"</code>.

Run: 34886537832, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected non-whitespace character after JSON at position 1 (line 1 column 2)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>31</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-infinity

Supplied input: string: <code>"Infinity"</code>.

Run: 34886546070, attempt 1.

Strict JSON input parsing: Rejected: <code>"Infinity" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>Infinity</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-infinity-approved

Supplied input: string: <code>"{&#92;"n&#92;":Infinity,&#92;"approved&#92;":true}"</code>.

Run: 34886555011, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token 'I', "{"n":Infinity,""... is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>Infinity</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>false</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>false</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": Infinity,<br>  "approved": true<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-leading-comment-object

Supplied input: string: <code>"/&#42; comment &#42;/{&#92;"n&#92;":1}"</code>.

Run: 34886564290, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token '/', "/&#42; comment &#42;/{"n":1}" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>" comment "</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-leading-dot

Supplied input: string: <code>".5"</code>.

Run: 34886572668, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token '.', ".5" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>0.5</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-leading-zero

Supplied input: string: <code>"017"</code>.

Run: 34886582779, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected number in JSON at position 1 (line 1 column 2)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>15</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-line-comment

Supplied input: string: <code>"// comment&#92;n31"</code>.

Run: 34886591237, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token '/', "// comment<br>31" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>" comment"</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-nan

Supplied input: string: <code>"NaN"</code>.

Run: 34886600853, attempt 1.

Strict JSON input parsing: Rejected: <code>"NaN" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>NaN</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-nan-approved

Supplied input: string: <code>"{&#92;"n&#92;":NaN,&#92;"approved&#92;":true}"</code>.

Run: 34886608941, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token 'N', "{"n":NaN,"appro"... is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>NaN</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>false</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": NaN,<br>  "approved": true<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-negative-infinity

Supplied input: string: <code>"-Infinity"</code>.

Run: 34886616413, attempt 1.

Strict JSON input parsing: Rejected: <code>No number after minus sign in JSON at position 1 (line 1 column 2)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>-Infinity</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-object-hex

Supplied input: string: <code>"{&#92;"n&#92;":0x1F}"</code>.

Run: 34886623884, attempt 1.

Strict JSON input parsing: Rejected: <code>Expected ',' or '}' after property value in JSON at position 6 (line 1 column 7)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>31</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": 31<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-object-leading-zero

Supplied input: string: <code>"{&#92;"n&#92;":017}"</code>.

Run: 34886632038, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected number in JSON at position 6 (line 1 column 7)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>15</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": 15<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-object-nan

Supplied input: string: <code>"{&#92;"n&#92;":NaN}"</code>.

Run: 34886640579, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token 'N', "{"n":NaN}" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>NaN</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>false</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": NaN<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-octal-prefix

Supplied input: string: <code>"0o17"</code>.

Run: 34886648329, attempt 1.

Runner evaluation error: <code>measure	Evaluate expressions	﻿2026-09-14T19:24:09.1377727Z ##&#91;error&#93;The template is not valid. .github/workflows/expr-conformance-probe.yml (Line: 35, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 36, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 37, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 38, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 39, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 40, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 41, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 42, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 43, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.,.github/workflows/expr-conformance-probe.yml (Line: 44, Col: 20): Unexpected character encountered while parsing number: o. Path '', line 1, position 1.</code>

Strict JSON input parsing: Rejected: <code>Unexpected non-whitespace character after JSON at position 1 (line 1 column 2)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | — |
| <code>fromJSON(inputs.value).approved != false</code> | — | — |
| <code>fromJSON(inputs.value).approved == true</code> | — | — |
| <code>fromJSON(inputs.value).n</code> | — | — |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | — |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | — |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | — |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | — |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | — |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | — |
| <code>fromJSON(inputs.value)</code> | — | — |
| <code>fromJSON(inputs.value) == null</code> | — | — |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | — |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | — |

## json-overflow-approved

Supplied input: string: <code>"{&#92;"n&#92;":1e309,&#92;"approved&#92;":true}"</code>.

Run: 34886657212, attempt 1.

Strict JSON input parsing: Parsed: <code>{ n: Infinity, approved: true }</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>Infinity</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>false</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>false</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": Infinity,<br>  "approved": true<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-plus

Supplied input: string: <code>"+1"</code>.

Run: 34886666071, attempt 1.

Runner evaluation error: <code>measure	Evaluate expressions	﻿2026-09-14T19:24:19.4667340Z ##&#91;error&#93;The template is not valid. .github/workflows/expr-conformance-probe.yml (Line: 35, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 36, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 37, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 38, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 39, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 40, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 41, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 42, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 43, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.,.github/workflows/expr-conformance-probe.yml (Line: 44, Col: 20): Unexpected character encountered while parsing value: +. Path '', line 0, position 0.</code>

Strict JSON input parsing: Rejected: <code>Unexpected token '+', "+1" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | — |
| <code>fromJSON(inputs.value).approved != false</code> | — | — |
| <code>fromJSON(inputs.value).approved == true</code> | — | — |
| <code>fromJSON(inputs.value).n</code> | — | — |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | — |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | — |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | — |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | — |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | — |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | — |
| <code>fromJSON(inputs.value)</code> | — | — |
| <code>fromJSON(inputs.value) == null</code> | — | — |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | — |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | — |

## json-single-quotes

Supplied input: string: <code>"{'role':'admin'}"</code>.

Run: 34886675366, attempt 1.

Strict JSON input parsing: Rejected: <code>Expected property name or '}' in JSON at position 1 (line 1 column 2)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "role": "admin"<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>false</code> |

## json-trailing-comma-array

Supplied input: string: <code>"&#91;1,&#93;"</code>.

Run: 34886684053, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected token '&#93;', "&#91;1,&#93;" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>&#91;<br>  1<br>&#93;</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-trailing-comma-object

Supplied input: string: <code>"{&#92;"role&#92;":&#92;"admin&#92;",}"</code>.

Run: 34886693702, attempt 1.

Strict JSON input parsing: Rejected: <code>Expected double-quoted property name in JSON at position 16 (line 1 column 17)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "role": "admin"<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>false</code> |

## json-trailing-comment

Supplied input: string: <code>"{&#92;"n&#92;":1} // comment"</code>.

Run: 34886702848, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected non-whitespace character after JSON at position 8 (line 1 column 9)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>1</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": 1<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-trailing-dot

Supplied input: string: <code>"1."</code>.

Run: 34886712073, attempt 1.

Strict JSON input parsing: Rejected: <code>Unterminated fractional number in JSON at position 2 (line 1 column 3)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>1</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-trailing-text-number

Supplied input: string: <code>"31 trailing"</code>.

Run: 34886720397, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected non-whitespace character after JSON at position 3 (line 1 column 4)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>31</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-trailing-text-object

Supplied input: string: <code>"{&#92;"n&#92;":1} garbage"</code>.

Run: 34886728526, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected non-whitespace character after JSON at position 8 (line 1 column 9)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>1</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": 1<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-two-objects

Supplied input: string: <code>"{&#92;"n&#92;":1}{&#92;"n&#92;":2}"</code>.

Run: 34886736545, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected non-whitespace character after JSON at position 7 (line 1 column 8)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>1</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "n": 1<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-undefined

Supplied input: string: <code>"undefined"</code>.

Run: 34886743906, attempt 1.

Strict JSON input parsing: Rejected: <code>"undefined" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>""</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>true</code> |

## json-unquoted-property

Supplied input: string: <code>"{role:'admin'}"</code>.

Run: 34886752231, attempt 1.

Strict JSON input parsing: Rejected: <code>Expected property name or '}' in JSON at position 1 (line 1 column 2)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>fromJSON(inputs.value).approved == false</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).approved != false</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).approved == true</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n</code> | — | <code>null</code> |
| <code>fromJSON(inputs.value).n &gt;= 0</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 100</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).n &lt;= 100</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &gt; 100)</code> | — | <code>true</code> |
| <code>!(fromJSON(inputs.value).n &lt; 0)</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).n &gt; 0</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value)</code> | — | <code>{<br>  "role": "admin"<br>}</code> |
| <code>fromJSON(inputs.value) == null</code> | — | <code>false</code> |
| <code>fromJSON(inputs.value).role == 'admin'</code> | — | <code>true</code> |
| <code>fromJSON(inputs.value).role != 'admin'</code> | — | <code>false</code> |

## coercion-strings

Run: 34886761198, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>'0x1F' == 123</code> | — | <code>false</code> |
| <code>'0x1F' == 15</code> | — | <code>false</code> |
| <code>'0x1F' == 17</code> | — | <code>false</code> |
| <code>'0x1F' == 31</code> | — | <code>true</code> |
| <code>'0x1F' == 0.5</code> | — | <code>false</code> |
| <code>'0x1F' == Infinity</code> | — | <code>false</code> |
| <code>'0x1F' == NaN</code> | — | <code>false</code> |
| <code>'0x1F' == 1</code> | — | <code>false</code> |
| <code>'0x1F' == 0</code> | — | <code>false</code> |
| <code>'0x1F' &gt; 30</code> | — | <code>true</code> |
| <code>'0x1F' &lt; 32</code> | — | <code>true</code> |
| <code>'0x1F' != NaN</code> | — | <code>true</code> |
| <code>'017' == 123</code> | — | <code>false</code> |
| <code>'017' == 15</code> | — | <code>false</code> |
| <code>'017' == 17</code> | — | <code>true</code> |
| <code>'017' == 31</code> | — | <code>false</code> |
| <code>'017' == 0.5</code> | — | <code>false</code> |
| <code>'017' == Infinity</code> | — | <code>false</code> |
| <code>'017' == NaN</code> | — | <code>false</code> |
| <code>'017' == 1</code> | — | <code>false</code> |
| <code>'017' == 0</code> | — | <code>false</code> |
| <code>'017' &gt; 30</code> | — | <code>false</code> |
| <code>'017' &lt; 32</code> | — | <code>true</code> |
| <code>'017' != NaN</code> | — | <code>true</code> |
| <code>'0o17' == 123</code> | — | <code>false</code> |
| <code>'0o17' == 15</code> | — | <code>true</code> |
| <code>'0o17' == 17</code> | — | <code>false</code> |
| <code>'0o17' == 31</code> | — | <code>false</code> |
| <code>'0o17' == 0.5</code> | — | <code>false</code> |
| <code>'0o17' == Infinity</code> | — | <code>false</code> |
| <code>'0o17' == NaN</code> | — | <code>false</code> |
| <code>'0o17' == 1</code> | — | <code>false</code> |
| <code>'0o17' == 0</code> | — | <code>false</code> |
| <code>'0o17' &gt; 30</code> | — | <code>false</code> |
| <code>'0o17' &lt; 32</code> | — | <code>true</code> |
| <code>'0o17' != NaN</code> | — | <code>true</code> |
| <code>'Infinity' == 123</code> | — | <code>false</code> |
| <code>'Infinity' == 15</code> | — | <code>false</code> |
| <code>'Infinity' == 17</code> | — | <code>false</code> |
| <code>'Infinity' == 31</code> | — | <code>false</code> |
| <code>'Infinity' == 0.5</code> | — | <code>false</code> |
| <code>'Infinity' == Infinity</code> | — | <code>true</code> |
| <code>'Infinity' == NaN</code> | — | <code>false</code> |
| <code>'Infinity' == 1</code> | — | <code>false</code> |
| <code>'Infinity' == 0</code> | — | <code>false</code> |
| <code>'Infinity' &gt; 30</code> | — | <code>true</code> |
| <code>'Infinity' &lt; 32</code> | — | <code>false</code> |
| <code>'Infinity' != NaN</code> | — | <code>true</code> |
| <code>'NaN' == 123</code> | — | <code>false</code> |
| <code>'NaN' == 15</code> | — | <code>false</code> |
| <code>'NaN' == 17</code> | — | <code>false</code> |
| <code>'NaN' == 31</code> | — | <code>false</code> |
| <code>'NaN' == 0.5</code> | — | <code>false</code> |
| <code>'NaN' == Infinity</code> | — | <code>false</code> |
| <code>'NaN' == NaN</code> | — | <code>false</code> |
| <code>'NaN' == 1</code> | — | <code>false</code> |
| <code>'NaN' == 0</code> | — | <code>false</code> |
| <code>'NaN' &gt; 30</code> | — | <code>false</code> |
| <code>'NaN' &lt; 32</code> | — | <code>false</code> |
| <code>'NaN' != NaN</code> | — | <code>true</code> |
| <code>'31' == 123</code> | — | <code>false</code> |
| <code>'31' == 15</code> | — | <code>false</code> |
| <code>'31' == 17</code> | — | <code>false</code> |
| <code>'31' == 31</code> | — | <code>true</code> |
| <code>'31' == 0.5</code> | — | <code>false</code> |
| <code>'31' == Infinity</code> | — | <code>false</code> |
| <code>'31' == NaN</code> | — | <code>false</code> |
| <code>'31' == 1</code> | — | <code>false</code> |
| <code>'31' == 0</code> | — | <code>false</code> |
| <code>'31' &gt; 30</code> | — | <code>true</code> |
| <code>'31' &lt; 32</code> | — | <code>true</code> |
| <code>'31' != NaN</code> | — | <code>true</code> |
| <code>'' == 123</code> | — | <code>false</code> |
| <code>'' == 15</code> | — | <code>false</code> |
| <code>'' == 17</code> | — | <code>false</code> |
| <code>'' == 31</code> | — | <code>false</code> |
| <code>'' == 0.5</code> | — | <code>false</code> |
| <code>'' == Infinity</code> | — | <code>false</code> |
| <code>'' == NaN</code> | — | <code>false</code> |
| <code>'' == 1</code> | — | <code>false</code> |
| <code>'' == 0</code> | — | <code>true</code> |
| <code>'' &gt; 30</code> | — | <code>false</code> |
| <code>'' &lt; 32</code> | — | <code>true</code> |
| <code>'' != NaN</code> | — | <code>true</code> |
| <code>' ' == 123</code> | — | <code>false</code> |
| <code>' ' == 15</code> | — | <code>false</code> |
| <code>' ' == 17</code> | — | <code>false</code> |
| <code>' ' == 31</code> | — | <code>false</code> |
| <code>' ' == 0.5</code> | — | <code>false</code> |
| <code>' ' == Infinity</code> | — | <code>false</code> |
| <code>' ' == NaN</code> | — | <code>false</code> |
| <code>' ' == 1</code> | — | <code>false</code> |
| <code>' ' == 0</code> | — | <code>true</code> |
| <code>' ' &gt; 30</code> | — | <code>false</code> |
| <code>' ' &lt; 32</code> | — | <code>true</code> |
| <code>' ' != NaN</code> | — | <code>true</code> |
| <code>'+1' == 123</code> | — | <code>false</code> |
| <code>'+1' == 15</code> | — | <code>false</code> |
| <code>'+1' == 17</code> | — | <code>false</code> |
| <code>'+1' == 31</code> | — | <code>false</code> |
| <code>'+1' == 0.5</code> | — | <code>false</code> |
| <code>'+1' == Infinity</code> | — | <code>false</code> |
| <code>'+1' == NaN</code> | — | <code>false</code> |
| <code>'+1' == 1</code> | — | <code>true</code> |
| <code>'+1' == 0</code> | — | <code>false</code> |
| <code>'+1' &gt; 30</code> | — | <code>false</code> |
| <code>'+1' &lt; 32</code> | — | <code>true</code> |
| <code>'+1' != NaN</code> | — | <code>true</code> |
| <code>'.5' == 123</code> | — | <code>false</code> |
| <code>'.5' == 15</code> | — | <code>false</code> |
| <code>'.5' == 17</code> | — | <code>false</code> |
| <code>'.5' == 31</code> | — | <code>false</code> |
| <code>'.5' == 0.5</code> | — | <code>true</code> |
| <code>'.5' == Infinity</code> | — | <code>false</code> |
| <code>'.5' == NaN</code> | — | <code>false</code> |
| <code>'.5' == 1</code> | — | <code>false</code> |
| <code>'.5' == 0</code> | — | <code>false</code> |
| <code>'.5' &gt; 30</code> | — | <code>false</code> |
| <code>'.5' &lt; 32</code> | — | <code>true</code> |
| <code>'.5' != NaN</code> | — | <code>true</code> |
| <code>'1.' == 123</code> | — | <code>false</code> |
| <code>'1.' == 15</code> | — | <code>false</code> |
| <code>'1.' == 17</code> | — | <code>false</code> |
| <code>'1.' == 31</code> | — | <code>false</code> |
| <code>'1.' == 0.5</code> | — | <code>false</code> |
| <code>'1.' == Infinity</code> | — | <code>false</code> |
| <code>'1.' == NaN</code> | — | <code>false</code> |
| <code>'1.' == 1</code> | — | <code>true</code> |
| <code>'1.' == 0</code> | — | <code>false</code> |
| <code>'1.' &gt; 30</code> | — | <code>false</code> |
| <code>'1.' &lt; 32</code> | — | <code>true</code> |
| <code>'1.' != NaN</code> | — | <code>true</code> |
| <code>'0123' == 123</code> | — | <code>true</code> |
| <code>'0123' == 15</code> | — | <code>false</code> |
| <code>'0123' == 17</code> | — | <code>false</code> |
| <code>'0123' == 31</code> | — | <code>false</code> |
| <code>'0123' == 0.5</code> | — | <code>false</code> |
| <code>'0123' == Infinity</code> | — | <code>false</code> |
| <code>'0123' == NaN</code> | — | <code>false</code> |
| <code>'0123' == 1</code> | — | <code>false</code> |
| <code>'0123' == 0</code> | — | <code>false</code> |
| <code>'0123' &gt; 30</code> | — | <code>true</code> |
| <code>'0123' &lt; 32</code> | — | <code>false</code> |
| <code>'0123' != NaN</code> | — | <code>true</code> |
| <code>'1e309' == 123</code> | — | <code>false</code> |
| <code>'1e309' == 15</code> | — | <code>false</code> |
| <code>'1e309' == 17</code> | — | <code>false</code> |
| <code>'1e309' == 31</code> | — | <code>false</code> |
| <code>'1e309' == 0.5</code> | — | <code>false</code> |
| <code>'1e309' == Infinity</code> | — | <code>true</code> |
| <code>'1e309' == NaN</code> | — | <code>false</code> |
| <code>'1e309' == 1</code> | — | <code>false</code> |
| <code>'1e309' == 0</code> | — | <code>false</code> |
| <code>'1e309' &gt; 30</code> | — | <code>true</code> |
| <code>'1e309' &lt; 32</code> | — | <code>false</code> |
| <code>'1e309' != NaN</code> | — | <code>true</code> |

## input-string-31

Supplied input: number: <code>"31"</code>.

Run: 34886771134, attempt 1.

Strict JSON input parsing: Parsed: <code>31</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>github.event.inputs.value == 31</code> | — | <code>true</code> |
| <code>github.event.inputs.value</code> | — | <code>"31"</code> |
| <code>inputs.value == 31</code> | — | <code>true</code> |
| <code>inputs.value</code> | — | <code>"31"</code> |

## input-string-0x1f

Supplied input: number: <code>"0x1F"</code>.

Run: 34886780658, attempt 1.

Strict JSON input parsing: Rejected: <code>Unexpected non-whitespace character after JSON at position 1 (line 1 column 2)</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>github.event.inputs.value == 31</code> | — | <code>true</code> |
| <code>github.event.inputs.value</code> | — | <code>"0x1F"</code> |
| <code>inputs.value == 31</code> | — | <code>true</code> |
| <code>inputs.value</code> | — | <code>"0x1F"</code> |

## input-string-infinity

Supplied input: number: <code>"Infinity"</code>.

Run: 34886791163, attempt 1.

Strict JSON input parsing: Rejected: <code>"Infinity" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>github.event.inputs.value == 31</code> | — | <code>false</code> |
| <code>github.event.inputs.value</code> | — | <code>"Infinity"</code> |
| <code>inputs.value == 31</code> | — | <code>false</code> |
| <code>inputs.value</code> | — | <code>"Infinity"</code> |

## input-string-nan

Supplied input: number: <code>"NaN"</code>.

Run: 34886800423, attempt 1.

Strict JSON input parsing: Rejected: <code>"NaN" is not valid JSON</code>.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>github.event.inputs.value == 31</code> | — | <code>false</code> |
| <code>github.event.inputs.value</code> | — | <code>"NaN"</code> |
| <code>inputs.value == 31</code> | — | <code>false</code> |
| <code>inputs.value</code> | — | <code>"NaN"</code> |

## input-number-31

Supplied input: number: <code>31</code>.

Dispatch error (input-validation): <code>Invalid value for input 'value'</code>

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>github.event.inputs.value == 31</code> | — | — |
| <code>github.event.inputs.value</code> | — | — |
| <code>inputs.value == 31</code> | — | — |
| <code>inputs.value</code> | — | — |

## decision-pitfalls

Run: 34886818131, attempt 1.

Strict JSON input parsing: Not measured.

| Expression | Service | Runner |
| --- | --- | --- |
| <code>false &amp;&amp; 'runs' &#124;&#124; 'skips'</code> | — | <code>"skips"</code> |
| <code>'ADMIN' == 'admin'</code> | — | <code>true</code> |
| <code>true &amp;&amp; 0 &#124;&#124; 'fallback'</code> | — | <code>"fallback"</code> |
| <code>017</code> | — | <code>17</code> |
| <code>fromJSON('{}').role == ''</code> | — | <code>true</code> |
| <code>fromJSON('{}').approved == false</code> | — | <code>true</code> |
| <code>fromJSON('{}').n == 0</code> | — | <code>true</code> |
| <code>NaN &gt; 100</code> | — | <code>false</code> |
| <code>!(NaN &gt; 100)</code> | — | <code>true</code> |
| <code>NaN &gt;= 0 &amp;&amp; NaN &lt;= 100</code> | — | <code>false</code> |
| <code>9007199254740993 == 9007199254740992</code> | — | <code>true</code> |
| <code>'false' &amp;&amp; 'runs' &#124;&#124; 'skips'</code> | — | <code>"runs"</code> |


