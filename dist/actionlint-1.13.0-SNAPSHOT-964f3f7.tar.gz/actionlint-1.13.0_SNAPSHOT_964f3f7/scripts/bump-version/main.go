package main

import (
	"bytes"
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

const releaseJobURL = "https://github.com/kjanat/actionlint/actions/workflows/release.yaml"

const releaseTimeZone = "Europe/Amsterdam"

type repo struct {
	ctx  context.Context
	root string
	out  io.Writer
}

func (r *repo) git(args ...string) (string, error) {
	cmd := exec.CommandContext(r.ctx, "git", args...)
	cmd.Dir = r.root
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = strings.TrimSpace(stdout.String())
		}
		return "", fmt.Errorf("`git %s` failed: %s: %w", strings.Join(args, " "), msg, err)
	}
	return strings.TrimSpace(stdout.String()), nil
}

func (r *repo) run(args ...string) error {
	_, _ = fmt.Fprintf(r.out, "+ git %s\n", strings.Join(args, " "))
	_, err := r.git(args...)
	return err
}

func (r *repo) preflight(tag string) error {
	top, err := r.git("rev-parse", "--show-toplevel")
	if err != nil {
		return err
	}
	abs, err := filepath.Abs(r.root)
	if err != nil {
		return err
	}
	resolved, err := filepath.EvalSymlinks(abs)
	if err != nil {
		return err
	}
	topResolved, err := filepath.EvalSymlinks(top)
	if err != nil {
		return err
	}
	if resolved != topResolved {
		return fmt.Errorf("this command must run at the repository root but %q is not %q", resolved, topResolved)
	}

	if out, err := r.git("status", "--porcelain", "--untracked-files=all"); err != nil {
		return err
	} else if out != "" {
		return errors.New("the working tree is not clean. commit, stash, or remove all changed and untracked files before bumping the version")
	}

	branch, err := r.git("rev-parse", "--abbrev-ref", "HEAD")
	if err != nil {
		return err
	}
	if branch != "master" {
		return fmt.Errorf("this command must run on the 'master' branch but the current branch is %q", branch)
	}

	if _, err := r.git("rev-parse", "--verify", "--quiet", "refs/tags/"+tag); err == nil {
		return fmt.Errorf("tag %s already exists", tag)
	}
	out, err := r.git("ls-remote", "--tags", "origin", "refs/tags/"+tag)
	if err != nil {
		return fmt.Errorf("could not check origin for tag %s: %w", tag, err)
	}
	if strings.TrimSpace(out) != "" {
		return fmt.Errorf("tag %s already exists on origin", tag)
	}
	return nil
}

func Main(ctx context.Context, args []string, stdout, stderr io.Writer) error {
	var check, commit, push bool
	var root, notes string

	flags := flag.NewFlagSet(args[0], flag.ContinueOnError)
	flags.BoolVar(&check, "check", false, "verify the declared version references and exit without modifying anything")
	flags.StringVar(&notes, "notes", "", "print the changelog section of the given version tag and exit")
	flags.BoolVar(&commit, "commit", false, "create the version bump commit and the version tag after verification")
	flags.BoolVar(&push, "push", false, "push the version bump commit and the version tag, implies -commit")
	flags.StringVar(&root, "root", ".", "repository root directory")
	flags.SetOutput(stderr)
	flags.Usage = func() {
		_, _ = fmt.Fprintln(stderr, "Usage: bump-version [FLAGS] VERSION\n\nFlags:")
		flags.PrintDefaults()
	}

	if err := flags.Parse(args[1:]); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return nil
		}
		return err
	}

	if notes != "" {
		if flags.NArg() != 0 {
			return fmt.Errorf("-notes takes no argument but got %v", flags.Args())
		}
		content, err := readChangelog(root)
		if err != nil {
			return err
		}
		section, err := sectionNotes(content, notes)
		if err != nil {
			return err
		}
		_, err = io.WriteString(stdout, section)
		return err
	}

	if check {
		if flags.NArg() != 0 {
			return fmt.Errorf("-check takes no argument but got %v", flags.Args())
		}
		if err := Check(root, targets, stdout); err != nil {
			return err
		}
		return checkChangelog(root)
	}

	if flags.NArg() != 1 {
		return fmt.Errorf("this command takes exactly one version argument such as 1.2.3 but got %v", flags.Args())
	}
	v, err := parseVersion(flags.Arg(0))
	if err != nil {
		return err
	}
	tag := "v" + v.String()

	r := &repo{ctx: ctx, root: root, out: stdout}
	if err := r.preflight(tag); err != nil {
		return err
	}
	if err := CheckChangelogRelease(root, v, stdout); err != nil {
		return err
	}

	_, _ = fmt.Fprintf(stdout, "Bumping the version to %s (tag: %s)\n", v, tag)
	if err := Bump(root, targets, v, stdout); err != nil {
		return err
	}
	zone, err := time.LoadLocation(releaseTimeZone)
	if err != nil {
		return err
	}
	if err := SectionizeChangelog(root, v, time.Now().In(zone).Format("2006-01-02"), stdout); err != nil {
		return err
	}

	if !commit && !push {
		_, _ = fmt.Fprint(stdout, "\nAll version references were updated and verified. To release, run:\n\n")
		_, _ = fmt.Fprintf(stdout, "  git add %s\n", strings.Join(append(paths(targets), changelogFile), " "))
		_, _ = fmt.Fprintf(stdout, "  git commit -m 'bump up version to %s'\n", tag)
		_, _ = fmt.Fprintf(stdout, "  git tag -s -m %s %s\n", tag, tag)
		_, _ = fmt.Fprint(stdout, "  git push origin master\n")
		_, _ = fmt.Fprintf(stdout, "  git push origin %s\n", tag)
		return nil
	}

	if err := r.run(append([]string{"add"}, append(paths(targets), changelogFile)...)...); err != nil {
		return err
	}
	if err := r.run("commit", "-m", "bump up version to "+tag); err != nil {
		return err
	}
	// A bare `git tag` picks up tag.gpgSign and then rejects the tag for having no message.
	if err := r.run("tag", "-s", "-m", tag, tag); err != nil {
		return err
	}

	if !push {
		_, _ = fmt.Fprintf(stdout, "\nThe bump commit and the tag %s were created locally. To release, run:\n\n", tag)
		_, _ = fmt.Fprint(stdout, "  git push origin master\n")
		_, _ = fmt.Fprintf(stdout, "  git push origin %s\n", tag)
		return nil
	}

	// docker/build-push-action resolves the tagged commit through the default branch, so master must be pushed first.
	if err := r.run("push", "origin", "master"); err != nil {
		return err
	}
	if err := r.run("push", "origin", tag); err != nil {
		return err
	}

	_, _ = fmt.Fprintf(stdout, "\nCheck the release progress at %s\n", releaseJobURL)
	return nil
}

func main() {
	// Interrupting the release flow must kill an in-flight `git push`, not orphan it.
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	err := Main(ctx, os.Args, os.Stdout, os.Stderr)
	stop()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
